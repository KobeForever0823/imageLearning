Buttons:
Browse folder: open gallery
1,2,3,4: rate each image
take picture: open camera
<< >>: move to last or next image

File path & name:
.csv:
pictures' csv: each csv file is put in /storage/emulated/0/DCIM/group7
               name: same as the picture folder
homeworks' csv: located in /storage/emulated/0/DCIM
                name:Homework1, 2, 3
photos' csv: photo.csv put in /storage/emulated/0/DCIM/Camera